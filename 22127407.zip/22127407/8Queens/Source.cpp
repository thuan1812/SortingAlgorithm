#include <iostream>

const int N = 8; // Number of queens and board size

// Function to check if the cell is captured by any queen in row, column, and diagonals
bool isCaptured(int row, int col, bool rowFlag[N], bool colFlag[N], bool pDiaFlag[2 * N - 1], bool sDiaFlag[2 * N - 1]) {
    return rowFlag[row] || colFlag[col] || pDiaFlag[row + col] || sDiaFlag[row - col + N - 1];
}

// Function to update captures at the cell
void updateCaptures(int i, int j, bool& rowFlag, bool& colFlag, bool pDiaFlag[2 * N - 1], bool sDiaFlag[2 * N - 1]) {
    rowFlag[&i] = true;
    colFlag[&j] = true;
    pDiaFlag[i + j] = true;
    sDiaFlag[i - j + N - 1] = true;
}

// Function to roll back captures at the cell
void rollbackCaptures(int i, int j, bool& rowFlag, bool& colFlag, bool pDiaFlag[2 * N - 1], bool sDiaFlag[2 * N - 1]) {
    rowFlag[&i] = false;
    colFlag[&j] = false;
    pDiaFlag[i + j] = false;
    sDiaFlag[i - j + N - 1] = false;
}

// Backtracking function to try placing queens
void TryQueen(int i, int j, bool rowFlag[N], bool colFlag[N], bool pDiaFlag[2 * N - 1], bool sDiaFlag[2 * N - 1]) {
    if (isCaptured(i, j, rowFlag, colFlag, pDiaFlag, sDiaFlag)) {
        return;
    }

    updateCaptures(i, j, *rowFlag, *colFlag, pDiaFlag, sDiaFlag);

    if (i == N - 1) {
        // Base case: if last row reached, print the result
        std::cout << "Solution found:" << std::endl;
        for (int row = 0; row < N; ++row) {
            for (int col = 0; col < N; ++col) {
                if (rowFlag[row] && colFlag[col]) {
                    std::cout << "Q ";
                }
                else {
                    std::cout << ". ";
                }
            }
            std::cout << std::endl;
        }
        std::cout << std::endl;
    }
    else {
        // Continue with the next row
        for (int k = 0; k < N; k++) {
            TryQueen(i + 1, k, rowFlag, colFlag, pDiaFlag, sDiaFlag);
        }
    }

    rollbackCaptures(i, j, *rowFlag, *colFlag, pDiaFlag, sDiaFlag);
}

int main() {
    bool rowFlag[N] = { false };        // Flags to keep track of occupied rows
    bool colFlag[N] = { false };        // Flags to keep track of occupied columns
    bool pDiaFlag[2 * N - 1] = { false }; // Flags to keep track of occupied positive diagonals
    bool sDiaFlag[2 * N - 1] = { false }; // Flags to keep track of occupied negative diagonals

    // Start trying to place queens from the first row
    for (int j = 0; j < N; j++) {
        TryQueen(0, j, rowFlag, colFlag, pDiaFlag, sDiaFlag);
    }

    return 0;
}
