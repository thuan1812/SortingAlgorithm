#pragma once
#include <iostream>
#include <time.h>
#include <string>
#include <fstream>
#include <cmath>
#include <string.h>
using namespace std;

void heapSort(int* a, int n);

long long heapSortWithCounting(int* a, int n);

void mergeSort(int* a, int n);

long long mergeSortWithCounting(int* a, int n);

void quickSort(int* a, int left, int right);

long long quickSortWithCounting(int* a, int left, int right);



void testAlgorithm();



template<class T>
void _swap(T& a, T& b) {
    T temp = a;
    a = b;
    b = temp;
}

void selectionSort(int* a, int n);

long long selectionSortWithCounting(int* a, int n);

void insertionSort(int* a, int n);

long long insertionSortWithCounting(int* a, int n);

void bubbleSort(int* a, int n);

long long bubbleSortWithCounting(int* a, int n);

void shakerSort(int* a, int n);

long long shakerSortWithCounting(int* a, int n);

void shellSort(int* a, int n);

long long shellSortWithCounting(int* a, int n);



void GenerateRandomData(int* a, int n);

void GenerateSortedData(int* a, int n);

void GenerateReverseData(int* a, int n);

void GenerateNearlySortedData(int* a, int n);

void GenerateData(int* a, int n, int dataType);



void flashSort(int* a, int n);

long long flashSortWithCounting(int* a, int n);



void countingSort(int* a, int n);

long long countingSortWithCounting(int* a, int n);

void radixSort(int* a, int n);

long long radixSortWithCounting(int* a, int n);