#include "sort.h"


void heapify(int* a, int n, int i) {
    int largest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;

    if (left < n && a[left] > a[largest]) {
        largest = left;
    }

    if (right < n && a[right] > a[largest]) {
        largest = right;
    }

    if (largest != i) {
        _swap(a[i], a[largest]);
        heapify(a, n, largest);
    }
}


void heapSort(int* a, int n) {
    for (int i = n / 2 - 1; i >= 0; i--) {
        heapify(a, n, i);
    }

    for (int i = n - 1; i >= 0; i--) {
        _swap(a[0], a[i]);
        heapify(a, i, 0);
    }
}

long long heapifyWithCounting(int* a, int n, int i) {
    long long cnt = 0;

    int largest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;

    if (++cnt && left < n && ++cnt && a[left] > a[largest]) {
        largest = left;
    }

    if (++cnt && right < n && ++cnt && a[right] > a[largest]) {
        largest = right;
    }

    if (++cnt && largest != i) {
        _swap(a[i], a[largest]);
        heapify(a, n, largest);
    }

    return cnt;
}

long long heapSortWithCounting(int* a, int n) {
    long long cnt = 0;

    for (int i = n / 2 - 1; ++cnt && i >= 0; i--) {
        cnt += heapifyWithCounting(a, n, i);
    }

    for (int i = n - 1; ++cnt && i >= 0; i--) {
        _swap(a[0], a[i]);
        cnt += heapifyWithCounting(a, i, 0);
    }

    return cnt;
}


void mergeSort(int* a, int n) {
    if (n <= 1) {
        return;
    }

    int mid = n / 2;
    int* left = new int[mid];
    int* right = new int[n - mid];

    for (int i = 0; i < mid; i++) {
        left[i] = a[i];
    }

    for (int i = mid; i < n; i++) {
        right[i - mid] = a[i];
    }

    mergeSort(left, mid);
    mergeSort(right, n - mid);

    int i = 0, j = 0, k = 0;

    while (i < mid && j < n - mid) {
        if (left[i] < right[j]) {
            a[k++] = left[i++];
        }
        else {
            a[k++] = right[j++];
        }
    }

    while (i < mid) {
        a[k++] = left[i++];
    }

    while (j < n - mid) {
        a[k++] = right[j++];
    }

    delete[] left;
    delete[] right;
}

long long mergeSortWithCounting(int* a, int n) {
    long long cnt = 0;

    if (++cnt && n <= 1) {
        return cnt;
    }

    int mid = n / 2;
    int* left = new int[mid];
    int* right = new int[n - mid];

    for (int i = 0; ++cnt && i < mid; i++) {
        left[i] = a[i];
    }

    for (int i = mid; ++cnt && i < n; i++) {
        right[i - mid] = a[i];
    }

    cnt += mergeSortWithCounting(left, mid);
    cnt += mergeSortWithCounting(right, n - mid);

    int i = 0, j = 0, k = 0;

    while (++cnt && i < mid && j < n - mid) {
        if (left[i] < right[j]) {
            a[k++] = left[i++];
        }
        else {
            a[k++] = right[j++];
        }
    }

    while (++cnt && i < mid) {
        a[k++] = left[i++];
    }

    while (++cnt && j < n - mid) {
        a[k++] = right[j++];
    }

    delete[] left;
    delete[] right;

    return cnt;
}


void quickSort(int* a, int left, int right) {
    int i = left, j = right;
    int pivot = a[(left + right) / 2];
    while (i <= j) {
        while (a[i] < pivot) {
            i++;
        }
        while (a[j] > pivot) {
            j--;
        }
        if (i <= j) {
            _swap(a[i], a[j]);
            i++;
            j--;
        }
    }

    if (left < j) {
        quickSort(a, left, j);
    }
    if (i < right) {
        quickSort(a, i, right);
    }
}

long long quickSortWithCounting(int* a, int left, int right) {
    long long cnt = 0;

    int i = left, j = right;
    int pivot = a[(left + right) / 2];
    while (++cnt && i <= j) {
        while (++cnt && a[i] < pivot) {
            i++;
        }
        while (++cnt && a[j] > pivot) {
            j--;
        }
        if (++cnt && i <= j) {
            _swap(a[i], a[j]);
            i++;
            j--;
        }
    }

    if (++cnt && left < j) {
        cnt += quickSortWithCounting(a, left, j);
    }

    if (++cnt && i < right) {
        cnt += quickSortWithCounting(a, i, right);
    }

    return cnt;
}


void testAlgorithm() {
    std::ifstream* fi = new std::ifstream[4];
    std::ofstream* fo = new std::ofstream[4];

    int inputSize[] = { 10000, 30000, 50000, 100000, 300000, 500000 };

    for (int i = 0; i < 6; i++) {
        std::cout << "Part " << i << "\n";
        //iterate through inputSize[]
        int n = inputSize[i];

        std::string* s = new std::string[4];

        s[0] = "randomized_data_" + std::to_string(n);
        s[1] = "sorted_data_" + std::to_string(n);
        s[2] = "reversed_sorted_data_" + std::to_string(n);
        s[3] = "nearly_sorted_data_" + std::to_string(n);

        for (int j = 0; j < 4; j++) {
            fi[j].open(s[j] + ".txt");
            fo[j].open(s[j] + "_result.txt");
        }

        int* a = new int[n];

        for (int j = 0; j < 4; j++) {
            for (int k = 0; k < n; k++) {
                fi[j] >> a[k];
            }

            clock_t start = clock();

            flashSort(a, n);

            clock_t end = clock();

            double timeUsed = (double)(end - start) / CLOCKS_PER_SEC;

            std::cout << "Time used for " << j << ": " << timeUsed << "\n";

            for (int k = 0; k < n; k++) {
                fo[j] << a[k] << " ";
            }

            fi[j].clear();
            fi[j].seekg(0, std::ios::beg);

            for (int k = 0; k < n; k++) {
                fi[j] >> a[k];
            }

            long long cmp = flashSortWithCounting(a, n);

            std::cout << "Comparisons used for " << j << ": " << cmp << "\n";
        }

        delete[] a;

        for (int j = 0; j < 4; j++) {
            fi[j].close();
            fo[j].close();
        }

        delete[] s;

    }

    delete[] fi;
    delete[] fo;

}


void selectionSort(int* a, int n) {
    for (int i = 0; i < n - 1; i++) {
        int minIndex = i;

        for (int j = i + 1; j < n; j++) {
            if (a[j] < a[minIndex]) {
                minIndex = j;
            }
        }

        if (minIndex != i) {
            _swap(a[i], a[minIndex]);
        }
    }
}

long long selectionSortWithCounting(int* a, int n) {
    long long cnt = 0;

    for (int i = 0; ++cnt && i < n - 1; i++) {
        int minIndex = i;

        for (int j = i + 1; ++cnt && j < n; j++) {
            if (++cnt && a[j] < a[minIndex]) {
                minIndex = j;
            }
        }

        if (++cnt && minIndex != i) {
            _swap(a[i], a[minIndex]);
        }
    }

    return cnt;
}

void insertionSort(int* a, int n) {
    for (int i = 1; i < n; i++) {
        int j = i - 1;
        int key = a[i];

        while (j >= 0 && a[j] > key) {
            a[j + 1] = a[j];
            j--;
        }

        a[j + 1] = key;
    }
}

long long insertionSortWithCounting(int* a, int n) {
    long long cnt = 0;

    for (int i = 1; ++cnt && i < n; i++) {
        int j = i - 1;
        int key = a[i];

        while (++cnt && j >= 0 && ++cnt && a[j] > key) {
            a[j + 1] = a[j];
            j--;
        }

        a[j + 1] = key;
    }

    return cnt;
}

void bubbleSort(int* a, int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (a[j] > a[j + 1]) {
                _swap(a[j], a[j + 1]);
            }
        }
    }
}

long long bubbleSortWithCounting(int* a, int n) {
    long long cnt = 0;

    for (int i = 0; ++cnt && i < n - 1; i++) {
        for (int j = 0; ++cnt && j < n - i - 1; j++) {
            if (++cnt && a[j] > a[j + 1]) {
                _swap(a[j], a[j + 1]);
            }
        }
    }

    return cnt;
}

void shakerSort(int* a, int n) {
    int left = 0;
    int right = n - 1;
    int k = 0;
    while (left < right) {
        for (int i = left; i < right; i++) {
            if (a[i] > a[i + 1]) {
                _swap(a[i], a[i + 1]);
                k = i;
            }
        }

        right = k;

        for (int i = right; i > left; i--) {
            if (a[i] < a[i - 1]) {
                _swap(a[i], a[i - 1]);
                k = i;
            }
        }

        left = k;
    }
}

long long shakerSortWithCounting(int* a, int n) {
    int left = 0;
    int right = n - 1;
    int k = 0;

    long long cnt = 0;

    while (++cnt&& left < right) {
        for (int i = left; ++cnt && i < right; i++) {
            if (++cnt && a[i] > a[i + 1]) {
                _swap(a[i], a[i + 1]);
                k = i;
            }
        }

        right = k;

        for (int i = right; ++cnt && i > left; i--) {
            if (++cnt && a[i] < a[i - 1]) {
                _swap(a[i], a[i - 1]);
                k = i;
            }
        }

        left = k;
    }

    return cnt;
}

void shellSort(int* a, int n) {
    int gap = n / 2;

    while (gap > 0) {
        for (int i = gap; i < n; i++) {
            int j = i - gap;
            int key = a[i];

            while (j >= 0 && a[j] > key) {
                a[j + gap] = a[j];
                j -= gap;
            }

            a[j + gap] = key;
        }

        gap /= 2;
    }
}

long long shellSortWithCounting(int* a, int n) {
    long long cnt = 0;
    int gap = n / 2;

    while (++cnt && gap > 0) {
        for (int i = gap; ++cnt && i < n; i++) {
            int j = i - gap;
            int key = a[i];

            while (++cnt && j >= 0 && ++cnt && a[j] > key) {
                a[j + gap] = a[j];
                j -= gap;
            }

            a[j + gap] = key;
        }

        gap /= 2;
    }

    return cnt;
}




template <class T>
void HoanVi(T& a, T& b)
{
    T x = a;
    a = b;
    b = x;
}

//-------------------------------------------------

// Hàm phát sinh mảng dữ liệu ngẫu nhiên
void GenerateRandomData(int* a, int n)
{
    srand((unsigned int)time(NULL));

    for (int i = 0; i < n; i++)
    {
        a[i] = rand() % n;
    }
}

// Hàm phát sinh mảng dữ liệu có thứ tự tăng dần
void GenerateSortedData(int* a, int n)
{
    for (int i = 0; i < n; i++)
    {
        a[i] = i;
    }
}

// Hàm phát sinh mảng dữ liệu có thứ tự ngược (giảm dần)
void GenerateReverseData(int* a, int n)
{
    for (int i = 0; i < n; i++)
    {
        a[i] = n - 1 - i;
    }
}

// Hàm phát sinh mảng dữ liệu gần như có thứ tự
void GenerateNearlySortedData(int* a, int n)
{
    for (int i = 0; i < n; i++)
    {
        a[i] = i;
    }
    srand((unsigned int)time(NULL));
    for (int i = 0; i < 10; i++)
    {
        int r1 = rand() % n;
        int r2 = rand() % n;
        HoanVi(a[r1], a[r2]);
    }
}

void GenerateData(int* a, int n, int dataType)
{
    switch (dataType)
    {
    case 0:	// ngẫu nhiên
        GenerateRandomData(a, n);
        break;
    case 1:	// có thứ tự
        GenerateSortedData(a, n);
        break;
    case 2:	// có thứ tự ngược
        GenerateReverseData(a, n);
        break;
    case 3:	// gần như có thứ tự
        GenerateNearlySortedData(a, n);
        break;
    default:
        printf("Error: unknown data type!\n");
    }
}



void flashSort(int* a, int n)
{
    int minVal = a[0];
    int maxIdx = 0;
    int m = int(0.43 * n);
    int* l = new int[m];
    for (int i = 0; i < m; i++) {
        l[i] = 0;
    }

    for (int i = 1; i < n; i++)
    {
        if (a[i] < minVal) {
            minVal = a[i];
        }
        if (a[i] > a[maxIdx]) {
            maxIdx = i;
        }

    }

    if (a[maxIdx] == minVal) {
        return;
    }

    double c1 = 1.00 * (m - 1) / (a[maxIdx] - minVal);

    for (int i = 0; i < n; i++)
    {
        int k = int(c1 * (a[i] - minVal));
        ++l[k];
    }

    for (int i = 1; i < m; i++) {
        l[i] += l[i - 1];
    }

    _swap(a[maxIdx], a[0]);

    int nmove = 0;
    int j = 0;
    int k = m - 1;
    int t = 0;
    int flash;

    while (nmove < n - 1)
    {
        while (j > l[k] - 1)
        {
            j++;
            k = int(c1 * (a[j] - minVal));
        }

        flash = a[j];

        if (k < 0) {
            break;
        }

        while (j != l[k])
        {
            k = int(c1 * (flash - minVal));
            int hold = a[t = --l[k]];

            a[t] = flash;
            flash = hold;

            ++nmove;
        }
    }
    delete[] l;
    insertionSort(a, n);
}

long long flashSortWithCounting(int* a, int n) {
    long long cmp = 0;

    int minVal = a[0];
    int maxIdx = 0;
    int m = int(0.45 * n);
    int* l = new int[m];
    for (int i = 0; ++cmp && i < m; i++) {
        l[i] = 0;
    }

    for (int i = 1; ++cmp && i < n; i++)
    {
        if (++cmp && a[i] < minVal) {
            minVal = a[i];
        }
        if (++cmp && a[i] > a[maxIdx]) {
            maxIdx = i;
        }

    }

    if (++cmp && a[maxIdx] == minVal) {
        return cmp;
    }

    double c1 = 1.00 * (m - 1) / (a[maxIdx] - minVal);

    for (int i = 0; ++cmp && i < n; i++)
    {
        int k = int(c1 * (a[i] - minVal));
        ++l[k];
    }

    for (int i = 1; ++cmp && i < m; i++) {
        l[i] += l[i - 1];
    }

    _swap(a[maxIdx], a[0]);

    int nmove = 0;
    int j = 0;
    int k = m - 1;
    int t = 0;
    int flash;

    while (++cmp && nmove < n - 1)
    {
        while (++cmp && j > l[k] - 1)
        {
            j++;
            k = int(c1 * (a[j] - minVal));
        }

        flash = a[j];

        if (++cmp && k < 0) {
            break;
        }

        while (++cmp && j != l[k])
        {
            k = int(c1 * (flash - minVal));
            int hold = a[t = --l[k]];

            a[t] = flash;
            flash = hold;

            ++nmove;
        }
    }
    delete[] l;
    cmp += insertionSortWithCounting(a, n);

    return cmp;
}


int generate() {
    std::ofstream* fo = new std::ofstream[4];
    fo[0].open("randomized_data_500000.txt");
    fo[1].open("sorted_data_500000.txt");
    fo[2].open("reversed_sorted_data_500000.txt");
    fo[3].open("nearly_sorted_data_500000.txt");

    int n = 500000;

    int* a = new int[n];

    for (int i = 0; i < 4; i++) {
        GenerateData(a, n, i);

        for (int j = 0; j < n; j++) {
            fo[i] << a[j] << " ";
        }
    }

    delete[] a;

    for (int i = 0; i < 4; i++) {
        fo[i].close();
    }

    delete[] fo;

    return 0;
}


void countingSort(int* a, int n) {
    int* c = new int[n];
    for (int i = 0; i < n; i++) {
        c[i] = 0;
    }

    for (int i = 0; i < n; i++) {
        c[a[i]]++;
    }

    for (int i = 1; i < n; i++) {
        c[i] += c[i - 1];
    }

    int* b = new int[n];
    for (int i = n - 1; i >= 0; i--) {
        b[c[a[i]] - 1] = a[i];
        c[a[i]]--;
    }

    for (int i = 0; i < n; i++) {
        a[i] = b[i];
    }

    delete[] c;
    delete[] b;
}

long long countingSortWithCounting(int* a, int n) {
    long long cnt = 0;

    int* c = new int[n];
    for (int i = 0; ++cnt && i < n; i++) {
        c[i] = 0;
    }

    for (int i = 0; ++cnt && i < n; i++) {
        c[a[i]]++;
    }

    for (int i = 1; ++cnt && i < n; i++) {
        c[i] += c[i - 1];
    }

    int* b = new int[n];
    for (int i = n - 1; ++cnt && i >= 0; i--) {
        b[c[a[i]] - 1] = a[i];
        c[a[i]]--;
    }

    for (int i = 0; ++cnt && i < n; i++) {
        a[i] = b[i];
    }

    delete[] c;
    delete[] b;

    return cnt;
}

void radixSort(int* a, int n)
{
    int* b = new int[n];

    int m = a[0], exp = 1;

    for (int i = 0; i < n; i++) {
        if (a[i] > m) {
            m = a[i];
        }
    }


    while (m / exp > 0)
    {
        int bucket[10] = { 0 };
        for (int i = 0; i < n; i++) {
            bucket[a[i] / exp % 10]++;
        }

        for (int i = 1; i < 10; i++) {
            bucket[i] += bucket[i - 1];
        }

        for (int i = n - 1; i >= 0; i--) {
            b[--bucket[a[i] / exp % 10]] = a[i];
        }

        for (int i = 0; i < n; i++) {
            a[i] = b[i];
        }

        exp *= 10;
    }
    delete[] b;
}

long long radixSortWithCounting(int* a, int n) {
    long long cmp = 0;

    int* b = new int[n];

    int m = a[0], exp = 1;

    for (int i = 0; ++cmp && i < n; i++) {
        if (++cmp && a[i] > m) {
            m = a[i];
        }
    }


    while (++cmp && m / exp > 0)
    {
        int bucket[10] = { 0 };
        for (int i = 0; ++cmp && i < n; i++) {
            bucket[a[i] / exp % 10]++;
        }

        for (int i = 1; ++cmp && i < 10; i++) {
            bucket[i] += bucket[i - 1];
        }

        for (int i = n - 1; ++cmp && i >= 0; i--) {
            b[--bucket[a[i] / exp % 10]] = a[i];
        }

        for (int i = 0; ++cmp && i < n; i++) {
            a[i] = b[i];
        }

        exp *= 10;
    }
    delete[] b;

    return cmp;
}